var endabgabe;
(function (endabgabe) {
    class Alles {
        constructor() {
            //
        }
        draw() {
            //
        }
        update() {
            this.draw();
        }
    }
    endabgabe.Alles = Alles;
})(endabgabe || (endabgabe = {}));
//# sourceMappingURL=alles.js.map