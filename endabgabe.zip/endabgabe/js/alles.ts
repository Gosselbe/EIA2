namespace endabgabe{

    export class Alles{
        x: number;
        y: number;
        type: number;
    
        constructor(){
            //
        }
    
        draw(): void {
            //
        }
    
        update(): void {
            this.draw();
        }
    
    }
    }