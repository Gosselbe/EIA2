interface Highscore {
    [key: string]: string;
}

interface Gamer {
    name: string;
    punkt: number;
}